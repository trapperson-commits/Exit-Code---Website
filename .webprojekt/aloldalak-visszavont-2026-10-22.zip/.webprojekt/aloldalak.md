# Aloldalak — helyi munka

A jóváhagyott megjelenésből készült hatoldalas honlap. Az index.html már a tényleges kezdőlap; a koncepcióválasztó megszűnt. A régi koncepciók forrásai megmaradtak, a kiadásba nem kerülnek.

Oldalak: index.html, music.html, our-story.html, live.html, photos.html, contact.html.
Közös stílus és működés: assets/site.css, assets/site.js.
Helyi build: node scripts/build-site.mjs. Eredménye dist/.
A képek a korábban jóváhagyott optimalizált másolatok; nincs új fotó. A koncert- és videóhírek megerősített adatok hiányában üres állapotot mutatnak. Az angol az aktív nyelv; nem működő fordítási kapcsoló nincs.

Csak a laptopra mentve. Commit és publikálás külön engedéllyel.
