
const menu=document.querySelector('.menu-button'),nav=document.querySelector('nav');menu.addEventListener('click',()=>{const open=menu.getAttribute('aria-expanded')!=='true';menu.setAttribute('aria-expanded',String(open));nav.classList.toggle('open',open)});nav.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{menu.setAttribute('aria-expanded','false');nav.classList.remove('open')}));document.addEventListener('keydown',e=>{if(e.key==='Escape'&&nav.classList.contains('open')){nav.classList.remove('open');menu.setAttribute('aria-expanded','false');menu.focus()}});document.querySelectorAll('audio').forEach(a=>a.addEventListener('play',()=>document.querySelectorAll('audio').forEach(other=>{if(other!==a)other.pause()})));

const portraits=document.querySelector('.portrait-panorama');
if(portraits&&!matchMedia('(prefers-reduced-motion: reduce)').matches){
 const observer=new IntersectionObserver(entries=>{if(entries.some(e=>e.isIntersecting)){portraits.classList.add('arriving');observer.disconnect();}},{threshold:.12});
 Promise.all([...portraits.querySelectorAll('img')].map(img=>img.decode().catch(()=>{}))).then(()=>observer.observe(portraits));
}

const wordmarkBand=document.querySelector('.wordmark-band');
if(wordmarkBand&&!matchMedia('(prefers-reduced-motion: reduce)').matches){
 const artwork=[...wordmarkBand.querySelectorAll('image')].map(el=>{const img=new Image();img.src=el.getAttribute('href');return img.decode().catch(()=>{});});
 Promise.all(artwork).then(()=>requestAnimationFrame(()=>wordmarkBand.classList.add('impact')));
}
const headerBand=document.querySelector('.header-band');
const updateHeaderHeight=()=>document.documentElement.style.setProperty('--header-height',headerBand.getBoundingClientRect().height+'px');
updateHeaderHeight();
new ResizeObserver(updateHeaderHeight).observe(headerBand);

if(!CSS.supports('height','100lvh')){
 let rockWidth=window.innerWidth;
 const sizeRock=()=>document.documentElement.style.setProperty('--rock-height',Math.max(window.innerHeight,window.screen.height)+'px');
 sizeRock();
 window.addEventListener('resize',()=>{if(Math.abs(window.innerWidth-rockWidth)>40){rockWidth=window.innerWidth;sizeRock();}},{passive:true});
}
