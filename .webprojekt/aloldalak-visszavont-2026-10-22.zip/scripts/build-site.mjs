import { readFile, writeFile, mkdir, copyFile, stat, rm } from 'node:fs/promises';
import path from 'node:path';

const root = process.cwd();
const output = path.join(root, 'dist');
if (path.dirname(output) !== root || path.basename(output) !== 'dist') throw new Error('Invalid output directory');
const pages = ['index.html', 'music.html', 'our-story.html', 'live.html', 'photos.html', 'contact.html'];
// Resolve every local dependency, including stylesheet assets, before replacing dist.
const files = new Set();
async function collect(relative) {
  if (files.has(relative)) return;
  const source = path.resolve(root, relative);
  if (!source.startsWith(root + path.sep)) throw new Error(`Invalid asset path: ${relative}`);
  if (!(await stat(source)).isFile()) throw new Error(`Missing asset: ${relative}`);
  files.add(relative);
  if (!/\.(?:html|css)$/.test(relative)) return;
  const content = await readFile(source, 'utf8');
  const references = content.matchAll(/(?:src|href)="([^"<>]+)"|url\(["']?([^\)"']+)["']?\)/g);
  for (const match of references) {
    const ref = match[1] || match[2];
    if (/^(?:https?:|mailto:|data:|#)/.test(ref)) continue;
    const clean = decodeURIComponent(ref.split('#')[0].split('?')[0]);
    if (clean) await collect(path.normalize(path.join(path.dirname(relative), clean)));
  }
}
for (const page of pages) await collect(page);
await rm(output, { recursive: true, force: true });
await mkdir(output, { recursive: true });
for (const relative of files) {
  const target = path.join(output, relative);
  await mkdir(path.dirname(target), { recursive: true });
  await copyFile(path.join(root, relative), target);
}
await writeFile(path.join(output, '404.html'), '<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Page not found | Exit Code</title><body style="background:#181818;color:white;font:20px Arial;padding:10vw"><h1>Page not found</h1><a href="index.html" style="color:white">Back to Exit Code</a></body></html>');
console.log(`Production site prepared in dist/: ${pages.length} pages and ${files.size - pages.length} assets.`);
